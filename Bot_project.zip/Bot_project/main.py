from config import currencies, TOKEN
from extensions import APIException, CurrencyConverter

import telebot
bot = telebot.TeleBot(TOKEN)


@bot.message_handler(commands=['start', 'help'])
def help(message: telebot.types.Message):
    text = 'Для того чтобы начать работу введите сообщение боту в следующем формате:\n<название валюты, цену которой надо yзнать> \
<название валюты, в которой надо yзнать цену  первой валюты> \
<количество переводимой валюты>\n Чтобы увидеть список всех доступных валют: /values'
    bot.reply_to(message, text)


@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
    text = 'Доступные валюты:'
    for i in currencies.keys():
        text = '\n'.join((text, i, ))
    bot.reply_to(message, text)


@bot.message_handler(content_types=['text', ])
def converter(message: telebot.types.Message):
    try:
        values = message.text.split(' ')

        if len(values) != 3:
            raise APIException('Неправильное количество аргументов, должно быть три.')

        base_key, quote, amount = values
        price = CurrencyConverter.get_price(base_key, quote, amount)

    except APIException as e:
        bot.reply_to(message, f'Ошибка пользователя\n{e}')
    except Exception as e:
        bot.reply_to(message, f'Не удалось обработать команду\n{e}')

    else:
        bot.reply_to(message, f"Цена {amount} {base_key} в {quote} - {price}")


bot.polling()
