TOKEN = "1770922016:AAFoIpvBLx4bmRGNS0oEaB6NUix8ngh3WPI"
currencies = {
    'евро': 'EUR',
    'доллар': 'USD',
    'рубль': 'RUB',
}
