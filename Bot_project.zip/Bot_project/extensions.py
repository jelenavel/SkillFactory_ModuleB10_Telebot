import requests
import json
from config import currencies


class APIException(Exception):
    pass


class CurrencyConverter:
    @staticmethod
    def get_price(base_key: str, quote: str, amount: str):
        if base_key == quote:
            raise APIException(f'Невозможно перевести одинаковые валюты {base_key}.')

        try:
            base_key_ticker = currencies[base_key]
        except KeyError:
            raise APIException(f'Не удалось обработать валюту {base_key}.')

        try:
            quote_ticker = currencies[quote]
        except KeyError:
            raise APIException(f'Не удалось обработать валюту {quote}.')

        try:
            amount = float(amount)
        except ValueError:
            raise APIException(f'Не удалось обработать количество {amount}.')
        r = requests.get(f"https://api.ratesapi.io/api/latest?base={base_key_ticker}&symbols={quote_ticker}")
        response = json.loads(r.content)
        price = response["rates"][currencies[quote]] * float(amount)
        return price


